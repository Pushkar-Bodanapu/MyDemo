import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/Nacha_Workflow')

suiteProperties.put('name', 'Nacha_Workflow')

suiteProperties.put('description', '')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("C:\\Eton-Project\\AutomationTesting\\Reports\\Nacha_Workflow\\20190708_204456\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/Nacha_Workflow', suiteProperties, [new TestCaseBinding('Test Cases/Nacha/Nacha Workflow-E2E', 'Test Cases/Nacha/Nacha Workflow-E2E',  [ 'Username' : 'Admin-Eton' , 'WireDetailsCounterparty' : 'Automation Script Run Entity' , 'WireDetailsForFurtherCreditto' : 'Credit to 1' , 'DocumentuploadChooseFiles' : 'C:\\Users\\pushkar.bodanapu\\Pictures\\Lion.jfif' , 'SummaryTransactionType' : 'Withdrawals-Cash' , 'TransactionInvoiceNumber' : 'NachaTP6' , 'AddTemplateClientEntity' : 'Automation Script Run Entity' , 'Password' : 'Password#1' , 'SummarySalesTax' : '15' , 'AddTemplateComments' : 'Nacha Workflow Processing' , 'DocumentuploadRelationshipType' : 'Client' , 'AccountingTaxCodePrincipal' : 'Accounting Fees' , 'TransactionInvoiceAmount' : '1556' , 'WireDetailsWiringInstructions' : '' , 'DocumentuploadRelationship' : 'Automation_Script Run1' , 'AddTemplateTemplate' : 'DryRunWDNACHA24' , 'TransactionDescDescription' : 'Test Description1' , 'AccountingTaxCodeIncome' : 'Accounting Fees' , 'SecurityQuestionaire' : 'aaa' , 'AddTemplateMemo' : '' , 'WireDetailsForFurtherCredittoACC' : 'Credit to Acc 1' , 'AccountingETCCode' : '' , 'AddTemplateAmount' : '1556' , 'TransactionDescMemo' : 'Test Memo1' , 'TransactionInvoiceDate' : '7/8/19' , 'SummaryDeliverableEvent' : '' , 'SummaryClientorPayororFund' : 'Automation Script Run Entity' , 'AccountingOnBehalfof' : 'Automation Script Run Entity' , 'AccountingPerctoIncome' : '23' , 'TransactionDescRemittance' : 'Test Remittance1' , 'SummaryTemplateName' : 'DryRunWDNACHA24' , 'WireDetailsForFurtherCredittoAddress' : 'Credit to Address 1' , 'SummaryTaxWithholding' : '10' , 'WireDetailsCounterpartyRelationship' : 'Automation_Script Run1' , 'SummaryClientorPayororFundRelationship' : 'Automation_Script Run1' , 'SummaryClientorTransactionAccount' : 'TestAutoscript (987654321)' , 'ApprovalInfoRoutetoWorkflow' : 'Client Bill Pay' , 'SummaryTemplateType' : 'Client Bill Pay' , 'SummaryTransactionMethod' : 'NACHA' , 'SummaryWithholdingThreshold' : '20' , 'BrowserURL' : 'http://qa.familyoperations.com/#/Login' , 'AccountingCusip' : '' ,  ])])
