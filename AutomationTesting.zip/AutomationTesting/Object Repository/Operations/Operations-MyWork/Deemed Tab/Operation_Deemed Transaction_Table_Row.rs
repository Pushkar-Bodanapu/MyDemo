<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operation_Deemed Transaction_Table_Row</name>
   <tag></tag>
   <elementGuidId>bfff8875-e8c5-4b4f-a704-c80a4db3acdf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;deemedTaskList&quot;]/div[4]/table/tbody/tr[1]/td[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;deemedTaskList&quot;]/div[4]/table/tbody/tr[1]</value>
   </webElementXpaths>
</WebElementEntity>
