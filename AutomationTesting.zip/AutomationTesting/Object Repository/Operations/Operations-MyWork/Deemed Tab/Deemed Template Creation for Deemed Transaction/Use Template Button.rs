<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Use Template Button</name>
   <tag></tag>
   <elementGuidId>62138c18-bf8c-4861-bc3a-0a5432f180e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title=&quot;Deemed Transaction Templates&quot;]//button[@title='Use Template']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title=&quot;Deemed Transaction Templates&quot;]//button[@title='Use Template']</value>
   </webElementXpaths>
</WebElementEntity>
