<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Transactions Templates_Search Input</name>
   <tag></tag>
   <elementGuidId>bd1e12c1-a25b-497f-a07a-074bcbf0a3ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(text(),'(Please Select')]/../span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[contains(text(),'(Please Select')]/../span/input</value>
   </webElementXpaths>
</WebElementEntity>
