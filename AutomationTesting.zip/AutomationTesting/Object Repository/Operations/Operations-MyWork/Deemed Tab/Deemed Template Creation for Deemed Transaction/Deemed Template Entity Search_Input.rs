<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Template Entity Search_Input</name>
   <tag></tag>
   <elementGuidId>bdaaa255-75af-42bf-8a48-f38505f0ba8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;ddlEntities-list&quot;])[2]/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//*[@id=&quot;ddlEntities-list&quot;])[2]/span/input</value>
   </webElementXpaths>
</WebElementEntity>
