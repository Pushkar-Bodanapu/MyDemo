<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Template_Entity_Select</name>
   <tag></tag>
   <elementGuidId>a2d4272e-e74c-4bdf-b71b-7e40a9143c0d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;ddlEntities_listbox&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//*[@id=&quot;ddlEntities_listbox&quot;])[2]</value>
   </webElementXpaths>
</WebElementEntity>
