<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Template_Relationship</name>
   <tag></tag>
   <elementGuidId>3d0b4c17-4a87-4c3f-8101-dd0e0719739d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='modal-body']/div[2]//label[.='Relationship:'])[1]/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='modal-body']/div[2]//label[.='Relationship:'])[1]/../select</value>
   </webElementXpaths>
</WebElementEntity>
