<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Trasaction_Approve Button</name>
   <tag></tag>
   <elementGuidId>9cc4cb0b-2471-41db-b879-93b128041365</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class=&quot;clearfix header well&quot;])[3]//button[contains(text(),'Approve')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class=&quot;clearfix header well&quot;])[3]//button[contains(text(),'Approve')]</value>
   </webElementXpaths>
</WebElementEntity>
