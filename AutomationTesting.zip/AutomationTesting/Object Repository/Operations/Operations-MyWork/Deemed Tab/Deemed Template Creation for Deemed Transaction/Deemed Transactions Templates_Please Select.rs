<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Transactions Templates_Please Select</name>
   <tag></tag>
   <elementGuidId>9a8f985e-5467-4a7e-aea2-66064b00d76d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title=&quot;Deemed Transaction Templates&quot;]/div[1]/div/div[2]/div/div[2]/div[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title=&quot;Deemed Transaction Templates&quot;]/div[1]/div/div[2]/div/div[2]/div[2]/span</value>
   </webElementXpaths>
</WebElementEntity>
