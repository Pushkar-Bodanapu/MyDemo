<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Transaction Template_Select Searchresults</name>
   <tag></tag>
   <elementGuidId>f250ee7d-1dfb-4547-89e1-9dd5344c062d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(text(),'(Please Select')]/.././div[3]/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[contains(text(),'(Please Select')]/.././div[3]/ul</value>
   </webElementXpaths>
</WebElementEntity>
