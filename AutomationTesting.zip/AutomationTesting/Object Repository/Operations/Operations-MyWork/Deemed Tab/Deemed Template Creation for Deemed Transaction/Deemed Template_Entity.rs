<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed Template_Entity</name>
   <tag></tag>
   <elementGuidId>1812bfe8-ff6e-45c4-bcb5-caf7a596fa28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='modal-body']/div[2]//label[.='Entity:']/../span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class='modal-body']/div[2]//label[.='Entity:']/../span</value>
   </webElementXpaths>
</WebElementEntity>
