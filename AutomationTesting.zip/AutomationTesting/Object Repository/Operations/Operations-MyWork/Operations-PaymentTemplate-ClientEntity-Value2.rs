<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-PaymentTemplate-ClientEntity-Value2</name>
   <tag></tag>
   <elementGuidId>a0de4c06-6cf7-470f-9700-6b9e7381a2ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;ddlEntities-list&quot;])[3]/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
