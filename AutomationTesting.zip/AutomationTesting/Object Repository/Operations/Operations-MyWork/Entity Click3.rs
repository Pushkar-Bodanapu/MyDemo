<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Entity Click3</name>
   <tag></tag>
   <elementGuidId>cd5805da-a8b7-43d4-910b-9e50b29aa09f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;ddlEntities_listbox&quot;])[3]/li</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//*[@id=&quot;ddlEntities_listbox&quot;])[3]/li</value>
   </webElementXpaths>
</WebElementEntity>
