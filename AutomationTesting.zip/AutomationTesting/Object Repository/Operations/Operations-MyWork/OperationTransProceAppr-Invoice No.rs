<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OperationTransProceAppr-Invoice No</name>
   <tag></tag>
   <elementGuidId>524c115e-605d-4859-b937-eb73926de91b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[2]/div[1]/div[1]/div/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
