<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OperationTransProceAppr-InvoiceDate</name>
   <tag></tag>
   <elementGuidId>8732eeb5-d429-4b99-9193-a511fbdbaf9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[2]/div[2]/div/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
