<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-PaymentTemplate-Template-Value2</name>
   <tag></tag>
   <elementGuidId>25c135ea-8eb9-4180-bf16-3d1b0fc7a6b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;ddlTemplates-list&quot;])[3]/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
