<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Accounting_GL Debit</name>
   <tag></tag>
   <elementGuidId>10e06812-4fe3-4892-b4b5-4dff7c5eff78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Accounting']//label[.= 'GL Debit:']/../span</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Accounting']//label[.= 'GL Debit:']/../span</value>
   </webElementXpaths>
</WebElementEntity>
