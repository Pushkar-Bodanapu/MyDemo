<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GL Debit_Input</name>
   <tag></tag>
   <elementGuidId>e70ffa53-4027-42a5-9764-8bdb8d0483fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;ddlGlDebit-list&quot;]/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;ddlGlDebit-list&quot;]/span/input</value>
   </webElementXpaths>
</WebElementEntity>
