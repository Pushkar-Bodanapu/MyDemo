<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GL Credit_Input</name>
   <tag></tag>
   <elementGuidId>5ad2b185-6b43-4601-8ce6-4df5317ae802</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;ddlGlCredit-list&quot;]/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;ddlGlCredit-list&quot;]/span/input</value>
   </webElementXpaths>
</WebElementEntity>
