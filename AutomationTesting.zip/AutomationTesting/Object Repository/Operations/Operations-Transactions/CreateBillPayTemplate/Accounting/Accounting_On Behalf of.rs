<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Accounting_On Behalf of</name>
   <tag></tag>
   <elementGuidId>062bfaa4-73e2-436e-a71b-3e813c0c63a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Accounting']//label[.= 'On Behalf Of:']/../select</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Accounting']//label[.= 'On Behalf Of:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
