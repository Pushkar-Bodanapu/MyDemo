<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Accounting_Perc toPrincipal</name>
   <tag></tag>
   <elementGuidId>83413171-717d-439d-882b-f0ae7d1a344e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Accounting']//label[.='% to Principal:']/../input</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Accounting']//label[.='% to Principal:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
