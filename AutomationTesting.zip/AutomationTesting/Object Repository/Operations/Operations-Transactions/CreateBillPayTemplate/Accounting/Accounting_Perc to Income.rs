<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Accounting_Perc to Income</name>
   <tag></tag>
   <elementGuidId>83bb29e4-4f8e-4a14-bda4-2157cea07b33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Accounting']//label[.='% to Income:']/../input</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Accounting']//label[.='% to Income:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
