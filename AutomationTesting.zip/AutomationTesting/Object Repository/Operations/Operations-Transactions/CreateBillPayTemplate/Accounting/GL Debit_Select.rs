<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GL Debit_Select</name>
   <tag></tag>
   <elementGuidId>8b8cb045-9c86-44c0-a6c3-91b244055b23</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;ddlGlDebit_listbox&quot;]/li</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;ddlGlDebit_listbox&quot;]/li</value>
   </webElementXpaths>
</WebElementEntity>
