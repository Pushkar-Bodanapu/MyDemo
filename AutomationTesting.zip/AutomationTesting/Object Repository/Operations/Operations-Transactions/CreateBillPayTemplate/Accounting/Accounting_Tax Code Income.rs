<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Accounting_Tax Code Income</name>
   <tag></tag>
   <elementGuidId>7e139a83-b32c-4b11-9624-11f580dc702f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Accounting']//label[.= 'Tax Code Income:']/../select</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Accounting']//label[.= 'Tax Code Income:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
