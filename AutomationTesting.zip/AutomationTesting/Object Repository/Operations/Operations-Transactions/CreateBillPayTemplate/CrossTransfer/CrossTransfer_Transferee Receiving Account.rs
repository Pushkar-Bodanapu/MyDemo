<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CrossTransfer_Transferee Receiving Account</name>
   <tag></tag>
   <elementGuidId>c415f003-b65e-4f79-93ee-f3870e614324</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//widget[@title='Cross Transfer']//label[text()='Transferee/Receiving Account'])[2]/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Cross Transfer']//label[.='Transferee/Receiving Account']/../select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[8]/div/div/div[2]/div/div[2]/div[1]/form/div[1]/select</value>
   </webElementXpaths>
</WebElementEntity>
