<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CrossTransfer_TransfereeRelationship</name>
   <tag></tag>
   <elementGuidId>148070b2-5143-4652-8b2f-70c018700412</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//widget[@title='Cross Transfer']//label[.='Transferee Relationship:'])[2]/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[8]/div/div/div[2]/div/div[1]/div/form/div/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Cross Transfer']//label[.='Transferee Relationship:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
