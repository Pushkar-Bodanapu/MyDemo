<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_Deliverable_Event</name>
   <tag></tag>
   <elementGuidId>f5611e34-862c-42a1-b2c0-87b1dee5315c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Summary']//label[.='Deliverable / Event:']/../span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Summary']//label[.='Deliverable / Event:']/../span</value>
   </webElementXpaths>
</WebElementEntity>
