<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_Client or Fund or Payor - Select</name>
   <tag></tag>
   <elementGuidId>5800b09a-64b0-4778-bb8d-5fb6d8c4eed3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;ddlPayorEntities_listbox&quot;]/li[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;ddlPayorEntities_listbox&quot;]/li[1]</value>
   </webElementXpaths>
</WebElementEntity>
