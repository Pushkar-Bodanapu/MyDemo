<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_ETC Code</name>
   <tag></tag>
   <elementGuidId>ab439119-7b22-412b-ab60-c942619f3817</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Summary']//label[.='ETC Code:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[5]/div[3]/form/div/select</value>
   </webElementXpaths>
</WebElementEntity>
