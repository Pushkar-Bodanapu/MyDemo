<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_SalesTax</name>
   <tag></tag>
   <elementGuidId>8667a498-bff8-420d-9b8d-bc1f6aef5536</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title=&quot;Summary&quot;]//label[text()='Sales Tax %:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[6]/div[1]/form/div/input</value>
   </webElementXpaths>
</WebElementEntity>
