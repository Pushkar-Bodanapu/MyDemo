<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_WithholdingThreshold</name>
   <tag></tag>
   <elementGuidId>7412b2de-7274-47d8-a306-8e7d44648249</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title=&quot;Summary&quot;]//label[text()='Withholding Threshold:']/../span/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[6]/div[2]/form/div/span/span/input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title=&quot;Summary&quot;]//label[text()='Withholding Threshold:']/../span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
