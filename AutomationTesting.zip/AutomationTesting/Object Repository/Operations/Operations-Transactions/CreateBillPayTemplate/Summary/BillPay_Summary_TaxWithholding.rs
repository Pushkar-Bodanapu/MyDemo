<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_TaxWithholding</name>
   <tag></tag>
   <elementGuidId>fdcf4162-7a83-48cf-806a-2426d921c019</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title=&quot;Summary&quot;]//label[text()='Tax Withholding %:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[5]/div[2]/form/div/input</value>
   </webElementXpaths>
</WebElementEntity>
