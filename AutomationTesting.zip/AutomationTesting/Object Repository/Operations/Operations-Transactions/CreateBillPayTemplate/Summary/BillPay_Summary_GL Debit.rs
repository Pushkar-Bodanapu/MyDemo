<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_GL Debit</name>
   <tag></tag>
   <elementGuidId>6f78b83a-f479-4d94-a886-84a4aa2cc63c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Summary']//label[.='GL Debit:']/../span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Summary']//label[.='GL Debit:']/../span</value>
   </webElementXpaths>
</WebElementEntity>
