<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BillPay_Summary_TemplateName</name>
   <tag></tag>
   <elementGuidId>5c7f7a09-c271-43c2-9836-1cb8d2ee0d09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[2]/div/div[2]/div[2]/form/div[1]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
