<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DTCDetails_FirmAccount</name>
   <tag></tag>
   <elementGuidId>932b699e-984b-491f-98d8-83c2db454698</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='DTC Details']//label[.='Firm Account#:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='DTC Details']//label[.='Firm Account#:']/../input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[11]/div/div/div[2]/div/div/div[3]/form/div/input</value>
   </webElementXpaths>
</WebElementEntity>
