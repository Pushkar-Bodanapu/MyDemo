<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DTCDetails_Firm Name and Address</name>
   <tag></tag>
   <elementGuidId>cb9d2ecc-554d-4b5c-a9cf-4edf86109abb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='DTC Details']//label[.='Firm Name and Address:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='DTC Details']//label[.='Firm Name and Address:']/../input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[11]/div/div/div[2]/div/div/div[2]/form/div/input</value>
   </webElementXpaths>
</WebElementEntity>
