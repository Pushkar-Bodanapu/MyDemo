<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>InternalTransfer_Transferee Receiving Account</name>
   <tag></tag>
   <elementGuidId>b2bb171c-0a73-4a5e-b100-2c7bc6b14cea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Internal Transfer']//label[.='Transferee/Receiving Account:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Internal Transfer']//label[.='Transferee/Receiving Account:']/../select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[7]/div/div/div[2]/div/div/div[1]/form/div[1]/select</value>
   </webElementXpaths>
</WebElementEntity>
