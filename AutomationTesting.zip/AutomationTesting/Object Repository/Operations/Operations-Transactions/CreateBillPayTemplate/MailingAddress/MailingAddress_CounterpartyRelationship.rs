<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MailingAddress_CounterpartyRelationship</name>
   <tag></tag>
   <elementGuidId>82503cbf-e144-41aa-b0ed-408372ccb6c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Mailing Address']//label[.='Counterparty Relationship:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Mailing Address']//label[.='Addresses:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
