<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MailingAddress_Counterparty</name>
   <tag></tag>
   <elementGuidId>42a7ff87-bbbc-45d5-a75c-156e13c45c35</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Mailing Address']//label[.='Counterparty:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Mailing Address']//label[.='Counterparty:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
