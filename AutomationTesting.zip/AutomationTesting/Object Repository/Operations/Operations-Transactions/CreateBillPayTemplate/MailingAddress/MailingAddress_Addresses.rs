<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MailingAddress_Addresses</name>
   <tag></tag>
   <elementGuidId>8127baa2-86bf-4408-97b9-1b8e300e724d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Mailing Address']//label[.='Addresses:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Mailing Address']//label[.='Addresses:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
