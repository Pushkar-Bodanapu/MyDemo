<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AutoDeposit_Investor Relationship</name>
   <tag></tag>
   <elementGuidId>41cae161-94e9-4a53-9389-aff82c1af651</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Auto Deposit']//label[.='Investor Relationship:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Auto Deposit']//label[.='Investor Relationship:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
