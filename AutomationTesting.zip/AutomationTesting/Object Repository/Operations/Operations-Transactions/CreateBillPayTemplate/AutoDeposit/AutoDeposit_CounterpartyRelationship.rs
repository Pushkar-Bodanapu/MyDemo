<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AutoDeposit_CounterpartyRelationship</name>
   <tag></tag>
   <elementGuidId>84376e7c-22ed-4525-a3b2-f89717f093b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Auto Deposit']//label[.='Counterparty Relationship:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[3]/div/div/div[2]/div/div/div[1]/form/div/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Auto Deposit']//label[.='Counterparty Relationship:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
