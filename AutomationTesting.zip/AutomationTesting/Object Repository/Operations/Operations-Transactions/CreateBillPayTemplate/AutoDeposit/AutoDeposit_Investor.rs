<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AutoDeposit_Investor</name>
   <tag></tag>
   <elementGuidId>24dfdcf8-c8d9-46f9-a389-95059147048d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Auto Deposit']//label[.='Investor:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Auto Deposit']//label[.='Investor:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
