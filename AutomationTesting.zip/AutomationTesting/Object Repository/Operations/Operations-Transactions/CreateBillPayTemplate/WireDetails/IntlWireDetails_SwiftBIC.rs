<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IntlWireDetails_SwiftBIC</name>
   <tag></tag>
   <elementGuidId>66f4812d-c52e-4aa8-8cbd-6d48fbf96db0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details']//label[.='Swift BIC:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details']//label[.='Swift BIC:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
