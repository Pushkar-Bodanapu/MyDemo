<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IntlWireDetails_InvestorRelationship</name>
   <tag></tag>
   <elementGuidId>a208eb07-650b-4790-86a1-b116f6295928</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][2]//label[.='Investor Relationship:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][2]//label[.='Investor Relationship:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
