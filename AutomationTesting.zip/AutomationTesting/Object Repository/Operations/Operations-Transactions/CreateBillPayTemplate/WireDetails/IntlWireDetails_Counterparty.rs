<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IntlWireDetails_Counterparty</name>
   <tag></tag>
   <elementGuidId>bb2c5465-7a0a-48a1-9192-f4437e3930ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][2]//label[.='Counterparty:']/../select</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][2]//label[.='Counterparty:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
