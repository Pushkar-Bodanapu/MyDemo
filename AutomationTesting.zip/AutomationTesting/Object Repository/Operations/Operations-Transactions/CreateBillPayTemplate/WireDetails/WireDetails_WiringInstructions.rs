<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WireDetails_WiringInstructions</name>
   <tag></tag>
   <elementGuidId>097d44ce-a0f2-40c9-947c-d6ea9ddc616f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][1]//label[.='Wiring Instructions:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[4]/div/div/div[2]/div/div/div[1]/form/div[2]/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][1]//label[.='Wiring Instructions:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
