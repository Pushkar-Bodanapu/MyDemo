<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IntlWireDetails_ForFurtherCreditto</name>
   <tag></tag>
   <elementGuidId>35f9390b-7a0f-4f4e-8a97-f71e9f3c2d6a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][2]//label[.='For Further Credit to:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][2]//label[.='For Further Credit to:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
