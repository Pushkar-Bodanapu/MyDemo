<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IntlWireDetails_ForFurtherCredittoAddress</name>
   <tag></tag>
   <elementGuidId>8a8676b6-5173-4b75-8ade-f919f25ec5bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][2]//label[.='For Further Credit to Address:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][2]//label[.='For Further Credit to Address:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
