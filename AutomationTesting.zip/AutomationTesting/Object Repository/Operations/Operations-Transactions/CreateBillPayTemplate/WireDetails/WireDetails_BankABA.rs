<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WireDetails_BankABA</name>
   <tag></tag>
   <elementGuidId>d61793cd-2955-432d-b383-6941b4319b79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][1]//label[.='Bank ABA:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][1]//label[.='Bank ABA:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
