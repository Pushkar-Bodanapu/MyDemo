<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WireDetails_BankNameandAddress</name>
   <tag></tag>
   <elementGuidId>98f50314-20a4-47ea-bef3-45d18fbe6cce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][1]//label[.='Bank Name and Address:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][1]//label[.='Bank Name and Address:']/../input</value>
   </webElementXpaths>
</WebElementEntity>
