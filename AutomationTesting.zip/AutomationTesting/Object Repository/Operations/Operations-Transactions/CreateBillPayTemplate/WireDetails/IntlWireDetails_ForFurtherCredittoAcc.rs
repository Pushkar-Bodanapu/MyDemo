<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IntlWireDetails_ForFurtherCredittoAcc</name>
   <tag></tag>
   <elementGuidId>8d582bb6-5ac7-4239-b9bd-baf81db13a3e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Wire Details'][2]//label[.='For Further Credit to A/C #:']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Wire Details'][2]//label[.='For Further Credit to A/C #:']/../input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[5]/div/div/div[2]/div/div/div[2]/form/div[3]/input</value>
   </webElementXpaths>
</WebElementEntity>
