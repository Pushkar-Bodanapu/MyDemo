<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TransactionDesc_Description</name>
   <tag></tag>
   <elementGuidId>de16af8d-fc93-49ae-b39b-162c5aac014e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Transaction Description'][1]//label[.='Description (line1):']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[10]/div/div/div[2]/div/div/div/form/div[2]/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Transaction Description'][1]//label[.='Description (line1):']/../input</value>
   </webElementXpaths>
</WebElementEntity>
