<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TransactionDesc_Remittance</name>
   <tag></tag>
   <elementGuidId>17f7321a-0e38-4af2-8342-f8b3217ce7ea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Transaction Description'][1]//label[.='Remittance (line1):']/../input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[10]/div/div/div[2]/div/div/div/form/div[1]/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Transaction Description'][1]//label[.='Remittance (line1):']/../input</value>
   </webElementXpaths>
</WebElementEntity>
