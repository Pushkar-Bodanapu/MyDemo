<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Bill Pay Template_Select_Search Results_TBD</name>
   <tag></tag>
   <elementGuidId>37e0486c-36f5-4963-bc4a-4bb5477df688</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@data-role='filtermulticheck']/form/ul//input[@value='AutoTestNTP']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@data-role='filtermulticheck']/form/ul/li</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@data-role='filtermulticheck']/form/ul//input[@value='AutoTestNTP']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>Value=AutoTestNTP- To be updated with dynamic Template Name</value>
   </webElementXpaths>
</WebElementEntity>
