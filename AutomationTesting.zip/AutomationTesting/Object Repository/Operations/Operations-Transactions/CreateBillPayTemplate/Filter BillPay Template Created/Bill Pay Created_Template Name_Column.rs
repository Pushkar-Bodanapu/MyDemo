<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Bill Pay Created_Template Name_Column</name>
   <tag></tag>
   <elementGuidId>3464564c-b8ee-48dc-b564-2b4f49ad5352</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;dataGridBillpay&quot;]//*[@data-title='Template Name']/a[1]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;dataGridBillpay&quot;]//*[@data-title='Template Name']/a[1]/span</value>
   </webElementXpaths>
</WebElementEntity>
