<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeemedANHAsset</name>
   <tag></tag>
   <elementGuidId>6d242547-1824-4c3c-a6a6-116c5c9d2425</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='modal-body']/div[2]//label[.='ANH Asset:'])[2]/../span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='modal-body']/div[2]//label[.='ANH Asset:'])[2]/../span/input</value>
   </webElementXpaths>
</WebElementEntity>
