<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed ANH Asset Selection</name>
   <tag></tag>
   <elementGuidId>6f014729-c8df-45ec-8807-8214b9517dff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//ul[@id='cusip_listbox'])[5]/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//ul[@id='cusip_listbox'])[5]/li</value>
   </webElementXpaths>
</WebElementEntity>
