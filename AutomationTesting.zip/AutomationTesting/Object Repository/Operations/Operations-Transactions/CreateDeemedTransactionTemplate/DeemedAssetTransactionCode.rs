<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeemedAssetTransactionCode</name>
   <tag></tag>
   <elementGuidId>6b1d71c5-21f1-43b8-922d-7c1e13993a3c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='modal-body']/div[2]//label[.='Asset Transaction Code:'])/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='modal-body']/div[2]//label[.='Asset Transaction Code:'])/../select</value>
   </webElementXpaths>
</WebElementEntity>
