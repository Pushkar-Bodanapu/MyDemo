<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed_Loan_PrivateLoan_InstrumentType</name>
   <tag></tag>
   <elementGuidId>e8c7106d-4327-4ac1-84dd-5e9df98478c9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Instrument Type:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[text()='Instrument Type:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
