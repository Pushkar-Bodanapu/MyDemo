<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed_Loan_PrivateLoan_LenderEntity</name>
   <tag></tag>
   <elementGuidId>144875f0-8f61-4780-98a4-f22bce411196</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Lender Entity:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[text()='Lender Entity:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
