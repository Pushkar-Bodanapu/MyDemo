<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed_Loan_PrivateLoan_Lender Relationship</name>
   <tag></tag>
   <elementGuidId>2573f5c3-ddff-4058-a333-eb583bf04724</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Lender Relationship:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[text()='Lender Relationship:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
