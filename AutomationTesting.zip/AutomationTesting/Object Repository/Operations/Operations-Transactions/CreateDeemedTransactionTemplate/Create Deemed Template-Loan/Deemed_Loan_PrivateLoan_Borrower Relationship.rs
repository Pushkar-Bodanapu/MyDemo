<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed_Loan_PrivateLoan_Borrower Relationship</name>
   <tag></tag>
   <elementGuidId>78d654da-c4af-49d9-ae32-ab710c94a403</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Borrower Relationship:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[text()='Borrower Relationship:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
