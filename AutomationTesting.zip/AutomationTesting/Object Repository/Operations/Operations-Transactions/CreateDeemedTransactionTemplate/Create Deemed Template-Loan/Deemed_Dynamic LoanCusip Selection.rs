<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Deemed_Dynamic LoanCusip Selection</name>
   <tag></tag>
   <elementGuidId>470108ad-9bb4-44b7-a203-40d8aea3f678</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;loancusip_listbox&quot;])[1]/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//*[@id=&quot;loancusip_listbox&quot;])[1]/li</value>
   </webElementXpaths>
</WebElementEntity>
