<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeemedANHAccount</name>
   <tag></tag>
   <elementGuidId>9ac29a65-9bb1-4bea-81b3-9b7c05492b08</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='modal-body']/div[2]//label[.='ANH Account:'])/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='modal-body']/div[2]//label[.='ANH Account:'])/../select</value>
   </webElementXpaths>
</WebElementEntity>
