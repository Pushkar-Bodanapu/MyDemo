<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeemedTransactionType</name>
   <tag></tag>
   <elementGuidId>1a0925a5-0ab2-4ac5-b6d5-0e7c039440f8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='modal-body']/div[2]//label[.='Transaction Type:']/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class='modal-body']/div[2]//label[.='Transaction Type:']/../select</value>
   </webElementXpaths>
</WebElementEntity>
