<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeemedCashTransactionCode</name>
   <tag></tag>
   <elementGuidId>47bd53a3-a64c-424d-844e-f8276976e663</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='modal-body']/div[2]//label[.='Cash Transaction Code:'])/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='modal-body']/div[2]//label[.='Cash Transaction Code:'])/../select</value>
   </webElementXpaths>
</WebElementEntity>
