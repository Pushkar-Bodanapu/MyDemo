<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeemedANHTrans_NewTemplate</name>
   <tag></tag>
   <elementGuidId>b68cffb5-3b60-401a-a8f3-f7d9088a50b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@title=&quot;New Template&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//button[@title=&quot;New Template&quot;]</value>
   </webElementXpaths>
</WebElementEntity>
