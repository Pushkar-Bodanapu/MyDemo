<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>StartDeemedWorkflow</name>
   <tag></tag>
   <elementGuidId>6691272f-64fd-449b-8a88-c5ba319f5210</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;modal-footer&quot;]//button[text()=&quot;Start Deemed Workflow...&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class=&quot;modal-footer&quot;]//button[text()=&quot;Start Deemed Workflow...&quot;]</value>
   </webElementXpaths>
</WebElementEntity>
