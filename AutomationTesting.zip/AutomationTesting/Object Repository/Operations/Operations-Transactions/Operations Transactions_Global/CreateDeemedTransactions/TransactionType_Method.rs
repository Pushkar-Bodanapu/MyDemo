<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TransactionType_Method</name>
   <tag></tag>
   <elementGuidId>f00903da-148f-4fbf-a750-70761547545b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;modal-body&quot;]//label[text()=&quot;Transaction Type / Method:&quot;]/../select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class=&quot;modal-body&quot;]//label[text()=&quot;Transaction Type / Method:&quot;]/../select</value>
   </webElementXpaths>
</WebElementEntity>
