<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TransactionAmount</name>
   <tag></tag>
   <elementGuidId>384f8d51-d440-4677-969a-8d158e97fa15</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;modal-body&quot;]//label[text()=&quot;Transaction Amount:&quot;]/../div/span/span/input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class=&quot;modal-body&quot;]//label[text()=&quot;Transaction Amount:&quot;]/../div/span/span/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
