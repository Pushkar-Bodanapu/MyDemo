<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>InitiatedTrans_Voided-InvoiceNumber</name>
   <tag></tag>
   <elementGuidId>0378346b-024c-4c82-af68-def8f4a79141</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;rejectedList&quot;]/div[4]/table/tbody/tr[1]/td[4]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>Table Row is not sorted out as approved task should be displayed first to pass this variable</value>
   </webElementXpaths>
</WebElementEntity>
