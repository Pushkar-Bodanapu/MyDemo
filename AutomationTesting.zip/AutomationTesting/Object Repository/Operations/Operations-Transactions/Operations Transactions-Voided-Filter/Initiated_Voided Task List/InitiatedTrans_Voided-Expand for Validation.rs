<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>InitiatedTrans_Voided-Expand for Validation</name>
   <tag></tag>
   <elementGuidId>f74f511b-d802-4efc-a583-c6673579829e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;payorList&quot;]/div[2]/table/tbody/tr/td[1]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
