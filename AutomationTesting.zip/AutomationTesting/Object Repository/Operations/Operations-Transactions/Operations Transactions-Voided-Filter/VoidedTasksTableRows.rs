<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VoidedTasksTableRows</name>
   <tag></tag>
   <elementGuidId>d9b4f6c3-f0bf-4ab1-ae7e-458ec53b61c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;rejectedList&quot;]/div[4]/table/tbody/tr</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
