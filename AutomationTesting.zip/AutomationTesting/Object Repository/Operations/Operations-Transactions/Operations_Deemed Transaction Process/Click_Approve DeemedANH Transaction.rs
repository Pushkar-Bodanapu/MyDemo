<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Click_Approve DeemedANH Transaction</name>
   <tag></tag>
   <elementGuidId>0da5223e-2889-4510-ac91-82cfc02f67d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;deemedTransactionsViewer&quot;]/wf-deemed-transactions-viewer/div[1]/div[3]/button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;deemedTransactionsViewer&quot;]/wf-deemed-transactions-viewer/div[1]/div[3]/button[1]</value>
   </webElementXpaths>
</WebElementEntity>
