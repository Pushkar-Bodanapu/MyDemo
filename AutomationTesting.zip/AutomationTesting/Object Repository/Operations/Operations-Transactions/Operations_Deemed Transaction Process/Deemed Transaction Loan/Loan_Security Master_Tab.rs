<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Loan_Security Master_Tab</name>
   <tag></tag>
   <elementGuidId>1d9a326f-a33c-4fcf-8100-564cd84618c8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id=&quot;deemedLoanPanel&quot;]/div[1]//span[text()=&quot;Security Master&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@id=&quot;deemedLoanPanel&quot;]/div[1]//span[text()=&quot;Security Master&quot;]</value>
   </webElementXpaths>
</WebElementEntity>
