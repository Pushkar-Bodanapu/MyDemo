<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SecurityMaster_PriceMultiplier</name>
   <tag></tag>
   <elementGuidId>878e6c62-4227-4254-b6c0-41fc3a034bb4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Price Multiplier:']/../div/common-data-entry/div/div/span/span/input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[text()='Price Multiplier:']/../div/common-data-entry/div/div/span/span/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
