<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SecurityMaster_ValuationMethod</name>
   <tag></tag>
   <elementGuidId>587564aa-f17e-4636-b1be-13653b88b921</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Valuation Method:']/../div/common-data-entry/div/div/span/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[text()='Valuation Method:']/../div/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
