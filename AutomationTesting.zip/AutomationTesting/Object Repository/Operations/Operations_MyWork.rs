<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations_MyWork</name>
   <tag></tag>
   <elementGuidId>bbcc41aa-4275-44bf-bb12-127c5f7e5c03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@data-ng-class=&quot;{'navbar-item-selected': selectedItem == 'OpsMyWork'}&quot;]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]/li[5]/ul/li[1]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//a[@data-ng-class=&quot;{'navbar-item-selected': selectedItem == 'OpsMyWork'}&quot;]</value>
   </webElementXpaths>
</WebElementEntity>
