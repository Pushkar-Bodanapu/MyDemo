<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Investment Object on the Home Screen</description>
   <name>Investment</name>
   <tag></tag>
   <elementGuidId>6c028d1c-9b61-4521-99f5-288f7208694e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;side-menu&quot;]//span[text()='Investment']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#side-menu > li:nth-child(3) > a > span.nav-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]/li[3]/a/span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class='sidebar-collapse']/ul/li[3]/a/span[1]</value>
   </webElementXpaths>
</WebElementEntity>
