<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SubmitSecurity</name>
   <tag></tag>
   <elementGuidId>f110dcb2-6a76-4eda-8573-55f44cb1d7da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#main > section.login-background > div > form:nth-child(6) > div:nth-child(3) > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value></value>
   </webElementXpaths>
</WebElementEntity>
