<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Security Questionaire</name>
   <tag></tag>
   <elementGuidId>d0cf0c03-5f8c-4851-8f07-ee1e0f43d511</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@type='password' and @ng-model='security.answer']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#main > section.login-background > div > form:nth-child(6) > div:nth-child(2) > input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;main&quot;]/section[1]/div/form[4]/div[2]/input</value>
   </webElementXpaths>
</WebElementEntity>
