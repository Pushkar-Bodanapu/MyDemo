<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Submit</name>
   <tag></tag>
   <elementGuidId>587cfdfe-e732-4fc2-9a96-a8fc863c4762</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#main > section.login-background > div > form.well.ng-dirty.ng-valid-parse.ng-valid.ng-valid-required > div:nth-child(3) > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//input[@ng-model='password']//following::button[1]</value>
   </webElementXpaths>
</WebElementEntity>
