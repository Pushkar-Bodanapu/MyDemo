<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Relationships</name>
   <tag></tag>
   <elementGuidId>b885343f-ed2e-4a3a-8091-d3cf4af8697a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;side-menu&quot;]//span[text()='Relationships']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#side-menu > li:nth-child(2) > a > span.nav-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//span[contains(text(),'Relationships') and @class='nav-label']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Work'])[2]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]/li[2]/a/span[1]</value>
   </webElementXpaths>
</WebElementEntity>
