<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>InvestmentWork_SecurityMaster_Summary Desc</name>
   <tag></tag>
   <elementGuidId>05a6c791-f9aa-4a6c-b135-7f85ac848ced</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;leftpane&quot;]/widget/div/div/div[2]/div/form/div/div[2]/common-data-entry/div/div/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
