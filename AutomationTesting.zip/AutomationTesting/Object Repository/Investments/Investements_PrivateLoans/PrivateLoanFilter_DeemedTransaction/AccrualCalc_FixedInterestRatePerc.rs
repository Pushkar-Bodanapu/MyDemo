<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AccrualCalc_FixedInterestRatePerc</name>
   <tag></tag>
   <elementGuidId>fda10b85-05e8-48ab-a870-d5cde05e358c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;Fixed Interest&quot;)]/../div[2]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//label[contains(text(),&quot;Fixed Interest&quot;)]/../div[2]/input</value>
   </webElementXpaths>
</WebElementEntity>
