<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Investment_Mywork</name>
   <tag></tag>
   <elementGuidId>11ca8db1-605a-4625-9996-5e88948a62d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@data-ng-class=&quot;{'navbar-item-selected': selectedItem == 'InvMyWork'}&quot;]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]/li[3]/ul/li[1]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//a[@data-ng-class=&quot;{'navbar-item-selected': selectedItem == 'InvMyWork'}&quot;]/span</value>
   </webElementXpaths>
</WebElementEntity>
