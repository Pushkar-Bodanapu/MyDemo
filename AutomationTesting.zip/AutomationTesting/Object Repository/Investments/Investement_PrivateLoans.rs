<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Investement_PrivateLoans</name>
   <tag></tag>
   <elementGuidId>9397afe2-96ab-47ff-bf99-9f5062403269</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;side-menu&quot;]//span[text()='Private Loans']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]//span[text()='Private Loans']</value>
   </webElementXpaths>
</WebElementEntity>
