<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CreateNewSecurity</name>
   <tag></tag>
   <elementGuidId>4e047560-1528-4483-a2cd-4e84bcd9d553</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#appContent > div:nth-child(2) > button</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@ng-click=&quot;createNewSecurity()&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@id=&quot;appContent&quot;]/div[1]/button</value>
   </webElementXpaths>
</WebElementEntity>
