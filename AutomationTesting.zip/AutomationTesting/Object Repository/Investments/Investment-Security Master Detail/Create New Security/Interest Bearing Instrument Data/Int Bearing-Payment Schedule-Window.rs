<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Int Bearing-Payment Schedule-Window</name>
   <tag></tag>
   <elementGuidId>f62e2cfd-f8ae-480b-aeff-d9ed41678c3a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Interest Bearing Instrument Data']/div/div/div[2]/div/button[2]/i</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Interest Bearing Instrument Data']/div/div/div[2]/div/button[2]/i</value>
   </webElementXpaths>
</WebElementEntity>
