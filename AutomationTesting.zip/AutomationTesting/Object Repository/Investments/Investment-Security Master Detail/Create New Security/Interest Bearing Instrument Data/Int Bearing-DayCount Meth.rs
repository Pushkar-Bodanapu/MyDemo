<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Int Bearing-DayCount Meth</name>
   <tag></tag>
   <elementGuidId>b3711fd6-0195-4d96-b2c5-1cee87b87977</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='interestForm']//label[text()=&quot;DayCount Meth:&quot;]/../common-data-entry/div/div/span/span/input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']/div/div[1]/div[4]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']//label[text()=&quot;DayCount Meth:&quot;]/../common-data-entry/div/div/span/span/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
