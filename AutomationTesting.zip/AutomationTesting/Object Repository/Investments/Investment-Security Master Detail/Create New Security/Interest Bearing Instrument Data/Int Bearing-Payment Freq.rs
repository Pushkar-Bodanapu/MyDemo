<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Int Bearing-Payment Freq</name>
   <tag></tag>
   <elementGuidId>9955ee43-d5f1-4914-914f-248ec07d1362</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='interestForm']//label[text()=&quot;Payment Freq:&quot;]/../common-data-entry/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']/div/div[2]/div[6]/common-data-entry/div/div/span/span/input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']//label[text()=&quot;Payment Freq:&quot;]/../common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
