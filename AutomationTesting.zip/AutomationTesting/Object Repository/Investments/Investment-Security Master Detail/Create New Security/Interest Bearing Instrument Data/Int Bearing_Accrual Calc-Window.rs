<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Int Bearing_Accrual Calc-Window</name>
   <tag></tag>
   <elementGuidId>c8d155a9-2b85-45ff-9604-12954f868612</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Interest Bearing Instrument Data']/div/div/div[2]/div/button[1]/i</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//widget[@title='Interest Bearing Instrument Data']/div/div/div[2]/div/button[1]/i</value>
   </webElementXpaths>
</WebElementEntity>
