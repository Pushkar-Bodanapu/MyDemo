<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Int Bearing-Irregular Payment Cycle MM DD</name>
   <tag></tag>
   <elementGuidId>614b034f-e499-4a67-a906-c1349e459e7e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='interestForm']//label[text()=&quot;Irregular Payment Cycle (MM-DD):&quot;]/../common-data-entry/div/div/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']/div/div[3]/div[1]/common-data-entry/div/div/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']//label[text()=&quot;Irregular Payment Cycle (MM-DD):&quot;]/../common-data-entry/div/div/span/input</value>
   </webElementXpaths>
</WebElementEntity>
