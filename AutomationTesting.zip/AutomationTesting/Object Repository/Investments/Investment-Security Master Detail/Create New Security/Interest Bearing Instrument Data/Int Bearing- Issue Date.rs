<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Int Bearing- Issue Date</name>
   <tag></tag>
   <elementGuidId>c4508782-7e2e-423d-a571-60413dec0470</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='interestForm']//label[text()=&quot;Issue Date:&quot;]/../common-data-entry/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']//label[text()=&quot;Issue Date:&quot;]/../common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='interestForm']/div/div[2]/div[2]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
