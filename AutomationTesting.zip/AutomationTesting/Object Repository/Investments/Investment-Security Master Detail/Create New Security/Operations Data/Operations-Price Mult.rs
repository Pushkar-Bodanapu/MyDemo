<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-Price Mult</name>
   <tag></tag>
   <elementGuidId>a4d8ec1c-7871-42fe-843b-4f1cd2a55ba1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='operationsForm']//label[text()=&quot;Price Mult:&quot;]/../common-data-entry/div/div/span/span/input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']/div/div[1]/div[4]/common-data-entry/div/div/span/span/input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']//label[text()=&quot;Price Mult:&quot;]/../common-data-entry/div/div/span/span/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
