<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-Dividend Payment Frequency</name>
   <tag></tag>
   <elementGuidId>5ccf824f-faff-4900-9814-5340fffd414b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='operationsForm']//label[text()=&quot;Dividend Payment Frequency:&quot;]/../common-data-entry/div/div/span/span/input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']//label[text()=&quot;Dividend Payment Frequency:&quot;]/../common-data-entry/div/div/span/span/input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']/div/div[3]/div[3]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
