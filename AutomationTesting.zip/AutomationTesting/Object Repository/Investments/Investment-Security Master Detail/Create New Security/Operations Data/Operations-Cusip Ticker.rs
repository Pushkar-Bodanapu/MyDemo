<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-Cusip Ticker</name>
   <tag></tag>
   <elementGuidId>80306ece-0517-46fa-abcc-ef6be475e145</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='operationsForm']//label[text()=&quot;Cusip Ticker:&quot;]/../common-data-entry/div/div/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']//label[text()=&quot;Cusip Ticker:&quot;]/../common-data-entry/div/div/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']/div/div[1]/div[1]/common-data-entry/div/div/span/input</value>
   </webElementXpaths>
</WebElementEntity>
