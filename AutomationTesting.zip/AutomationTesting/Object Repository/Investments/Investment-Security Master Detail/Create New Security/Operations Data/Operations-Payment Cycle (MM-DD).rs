<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-Payment Cycle (MM-DD)</name>
   <tag></tag>
   <elementGuidId>b0a21ab1-dd60-4f68-8461-4a898498e832</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='operationsForm']//label[text()=&quot;Payment Cycle (MM-DD):&quot;]/../common-data-entry/div/div/span/input







</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']/div/div[3]/div[4]/common-data-entry/div/div/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']//label[text()=&quot;Payment Cycle (MM-DD):&quot;]/../common-data-entry/div/div/span/input</value>
   </webElementXpaths>
</WebElementEntity>
