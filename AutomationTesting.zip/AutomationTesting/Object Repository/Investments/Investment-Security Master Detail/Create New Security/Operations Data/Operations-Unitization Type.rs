<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Operations-Unitization Type</name>
   <tag></tag>
   <elementGuidId>50dc9cd5-1231-47ef-9c6f-e0e5bfa4b324</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='operationsForm']//label[text()=&quot;Unitization Type:&quot;]/../common-data-entry/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']/div/div[3]/div[1]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='operationsForm']//label[text()=&quot;Unitization Type:&quot;]/../common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
