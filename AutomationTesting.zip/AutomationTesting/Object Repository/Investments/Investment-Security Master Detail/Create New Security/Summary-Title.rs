<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Summary-Title</name>
   <tag></tag>
   <elementGuidId>b7938066-6d02-4b48-87fc-376771598b46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title='Summary']/div/div/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#leftpane > widget:nth-child(1) > div > div > div.ibox-title > h5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;leftpane&quot;]/widget[1]/div/div/div[1]/h5</value>
   </webElementXpaths>
</WebElementEntity>
