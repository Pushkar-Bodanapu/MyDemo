<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Acc and Tax-Tax-Income Category</name>
   <tag></tag>
   <elementGuidId>0035df0e-506f-402a-b73e-a7192f04c59d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='accountingForm']//label[text()=&quot;Tax-Income Category:&quot;]/../common-data-entry/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='accountingForm']/div/div/div[3]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='accountingForm']//label[text()=&quot;Tax-Income Category:&quot;]/../common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
