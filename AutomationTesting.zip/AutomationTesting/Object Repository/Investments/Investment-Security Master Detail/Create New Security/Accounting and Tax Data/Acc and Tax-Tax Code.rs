<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Acc and Tax-Tax Code</name>
   <tag></tag>
   <elementGuidId>c75c71eb-1a4d-46e8-a70d-59283a4f117e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='accountingForm']//label[text()=&quot;Tax Code:&quot;]/../common-data-entry/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='accountingForm']/div/div/div[4]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='accountingForm']//label[text()=&quot;Tax Code:&quot;]/../common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
