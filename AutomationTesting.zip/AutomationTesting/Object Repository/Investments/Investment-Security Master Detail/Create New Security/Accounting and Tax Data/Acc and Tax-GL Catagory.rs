<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Acc and Tax-GL Catagory</name>
   <tag></tag>
   <elementGuidId>7c6701dd-2985-42e2-ad90-6d63cae574b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='accountingForm']//label[text()=&quot;GL Category:&quot;]/../common-data-entry/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='accountingForm']/div/div/div[2]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//form[@name='accountingForm']//label[text()=&quot;GL Category:&quot;]/../common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
