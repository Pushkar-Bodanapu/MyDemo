<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Summary_Cusip</name>
   <tag></tag>
   <elementGuidId>74b30d36-9e15-48c1-b6d3-2bd3792999cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#csp_cusip_text > div > div > span > input</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//widget[@title=&quot;Summary&quot;]//*[@id=&quot;csp_cusip_text&quot;]/div/div/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;csp_cusip_text&quot;]/div/div/span/input</value>
   </webElementXpaths>
</WebElementEntity>
