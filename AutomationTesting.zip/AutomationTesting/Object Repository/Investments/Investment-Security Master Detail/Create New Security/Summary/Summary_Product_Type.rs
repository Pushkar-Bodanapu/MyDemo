<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Summary_Product_Type</name>
   <tag></tag>
   <elementGuidId>8726111f-8707-49bb-8970-b88576843790</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//common-data-entry[@id='itr_row_id_combo']/div/div/span/span/input</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#itr_row_id_combo > div > div > span > span > input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;itr_row_id_combo&quot;]/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
