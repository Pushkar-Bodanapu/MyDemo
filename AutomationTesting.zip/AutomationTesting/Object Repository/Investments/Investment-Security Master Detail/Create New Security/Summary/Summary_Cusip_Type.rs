<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Summary_Cusip_Type</name>
   <tag></tag>
   <elementGuidId>67faf5ad-7c18-4bdc-9b49-515693ad83ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#leftpane > widget > div > div > div.ibox-content > div > form > div > div:nth-child(3) > common-data-entry > div > div > span > span > input</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='leftpane']/widget/div/div/div[2]/div/form/div/div[3]/common-data-entry/div/div/span/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@id='leftpane']/widget/div/div/div[2]/div/form/div/div[3]/common-data-entry/div/div/span/span/input</value>
   </webElementXpaths>
</WebElementEntity>
