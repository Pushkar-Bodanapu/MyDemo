<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Summary_Manager_Fund</name>
   <tag></tag>
   <elementGuidId>d1c529cc-2c12-436b-ab8f-712574931056</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#leftpane > widget > div > div > div.ibox-content > div > form > div > div:nth-child(5) > common-data-entry > div > div > span > span > input</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//input[@type='text'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//input[@type='text'])[3]</value>
   </webElementXpaths>
</WebElementEntity>
