<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Summary_CusipDescription</name>
   <tag></tag>
   <elementGuidId>3de31441-34dd-47f3-ac8e-dd5704fca2cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#leftpane > widget > div > div > div.ibox-content > div > form > div > div.col-sm-4.minimal-column-padding > common-data-entry > div > div > span > input</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Cusip Description'])[1]/following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@id='leftpane']/widget/div/div/div[2]/div/form/div/div[2]/common-data-entry/div/div/span/input</value>
   </webElementXpaths>
</WebElementEntity>
