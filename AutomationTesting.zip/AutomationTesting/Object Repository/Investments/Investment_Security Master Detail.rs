<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Investment_Security Master Detail</name>
   <tag></tag>
   <elementGuidId>80f5ca14-1e5f-4868-8c7d-870106e65621</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;side-menu&quot;]//span[text()='Security Master Detail']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#side-menu > li:nth-child(3) > ul > li:nth-child(6) > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//ul[@id='side-menu']/li[3]/ul/li[6]/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]//span[text()='Security Master Detail']</value>
   </webElementXpaths>
</WebElementEntity>
