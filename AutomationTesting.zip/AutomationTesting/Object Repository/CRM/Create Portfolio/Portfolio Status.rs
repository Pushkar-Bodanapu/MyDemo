<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Portfolio Status</name>
   <tag></tag>
   <elementGuidId>37d8f9c6-6bc8-4640-b445-9c5b82b9a099</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;prtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/prt-template/form/div/div[2]/lookup[2]/select[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
