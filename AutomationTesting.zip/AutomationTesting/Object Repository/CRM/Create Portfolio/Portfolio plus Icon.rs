<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Portfolio plus Icon</name>
   <tag></tag>
   <elementGuidId>78399a13-5c2e-4e0d-a77f-ce70a0d43610</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;rdtTabPane&quot;]/div/div/div[3]/crm-portfolio-widget/div[1]/button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
