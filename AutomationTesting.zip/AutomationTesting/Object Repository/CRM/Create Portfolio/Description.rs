<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Description</name>
   <tag></tag>
   <elementGuidId>e51137da-56b0-47f0-ba38-4ef4f0d3144e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;prtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/prt-template/form/div/div[1]/textarea</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
