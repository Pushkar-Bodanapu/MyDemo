<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>plus</name>
   <tag></tag>
   <elementGuidId>e9740f50-fc51-4c11-bb89-3e4ee7ac89d3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
