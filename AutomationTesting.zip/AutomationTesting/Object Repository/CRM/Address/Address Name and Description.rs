<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Address Name and Description</name>
   <tag></tag>
   <elementGuidId>94f069f4-e558-408f-87d2-0bab77d833c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;adtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/adt-template/form/div/div[1]/input[1]
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
