<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Address Phone Lnadline</name>
   <tag></tag>
   <elementGuidId>ea1ba241-bcbd-4586-af61-7242ab49d148</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;adtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/adt-template/form/div/div[2]/input[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
