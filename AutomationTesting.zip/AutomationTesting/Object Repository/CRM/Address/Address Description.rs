<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Address Description</name>
   <tag></tag>
   <elementGuidId>23e4d055-fa71-4295-af96-65e1c9cc29f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;adtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/adt-template/form/div/div[3]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
