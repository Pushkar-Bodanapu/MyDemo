<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Address Line 3</name>
   <tag></tag>
   <elementGuidId>8cee3573-5a01-4ed0-8f72-138973c2689f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;adtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/adt-template/form/div/div[1]/input[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
