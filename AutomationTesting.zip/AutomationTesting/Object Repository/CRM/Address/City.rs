<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>City</name>
   <tag></tag>
   <elementGuidId>78316eaa-6715-4b2e-8c4f-1389e15e2801</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;adtInfoPane&quot;]/workflow-panel/div[3]/div/div[1]/div[2]/div/adt-template/form/div/div[1]/input[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
