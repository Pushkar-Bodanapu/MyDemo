<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Security Submit</name>
   <tag></tag>
   <elementGuidId>8c5e2978-d91b-436c-9bac-1a0d2d0a4ae1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
