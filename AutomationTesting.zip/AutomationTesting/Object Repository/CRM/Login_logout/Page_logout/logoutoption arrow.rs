<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>logoutoption arrow</name>
   <tag></tag>
   <elementGuidId>fbb68d29-ae06-4b7d-98d2-b69a2794cf97</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
