<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AccountsTab on RelationshipScreen</name>
   <tag></tag>
   <elementGuidId>5c3bbfec-7b36-4bf4-95e4-5e1a7b0db7cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;rdtTabPane&quot;]//*[contains(text(),&quot;Accounts&quot;)])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//*[@id=&quot;rdtTabPane&quot;]//*[contains(text(),&quot;Accounts&quot;)])[1]</value>
   </webElementXpaths>
</WebElementEntity>
