<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EntityType</name>
   <tag></tag>
   <elementGuidId>ddcff048-59b4-4f8a-9baa-c2d6a606277f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;edtApprovalForm&quot;)/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-4&quot;]/common-data-entry[@class=&quot;ng-pristine ng-untouched ng-valid&quot;]/div[1]/div[1]/span[@class=&quot;k-widget k-combobox k-header ng-pristine ng-untouched ng-valid k-combobox-clearable eton-validate eton-input&quot;]/span[@class=&quot;k-dropdown-wrap k-state-default k-state-hover&quot;]/span[@class=&quot;k-select&quot;]/span[@class=&quot;k-icon k-i-arrow-60-down&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;edtApprovalForm&quot;]/div/div[1]/common-data-entry[3]/div/div/span/span/input
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>k-icon k-i-arrow-60-down</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;edtApprovalForm&quot;)/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-4&quot;]/common-data-entry[@class=&quot;ng-pristine ng-untouched ng-valid&quot;]/div[1]/div[1]/span[@class=&quot;k-widget k-combobox k-header ng-pristine ng-untouched ng-valid k-combobox-clearable eton-validate eton-input&quot;]/span[@class=&quot;k-dropdown-wrap k-state-default k-state-hover&quot;]/span[@class=&quot;k-select&quot;]/span[@class=&quot;k-icon k-i-arrow-60-down&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='edtApprovalForm']/div/div/common-data-entry[3]/div/div/span/span/span[2]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Entity Type'])[2]/following::span[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Entity Status'])[2]/following::span[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Entity Short Name'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Entity Tax Status'])[1]/preceding::span[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//common-data-entry[3]/div/div/span/span/span[2]/span</value>
   </webElementXpaths>
</WebElementEntity>
