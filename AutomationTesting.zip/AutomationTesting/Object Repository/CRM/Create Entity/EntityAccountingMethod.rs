<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EntityAccountingMethod</name>
   <tag></tag>
   <elementGuidId>84aa09e4-5c50-4680-b490-2edf2af5887d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;edtApprovalForm&quot;]/div/div[3]/common-data-entry[2]/div/div/span/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
