<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SECclass</name>
   <tag></tag>
   <elementGuidId>e954c8e1-4055-4003-9a97-1d8dceefee61</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;acdApprovalForm&quot;]/div/div[3]/div[4]/common-data-entry/div/div/span/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
