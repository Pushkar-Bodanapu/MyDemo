<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GL Account Cash</name>
   <tag></tag>
   <elementGuidId>9ec65c0a-35a7-48a3-b492-97d6119f73ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;acdApprovalForm&quot;]/div/div[4]/div[2]/common-data-entry/div/div/span/span/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
