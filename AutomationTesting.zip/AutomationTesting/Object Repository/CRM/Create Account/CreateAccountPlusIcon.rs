<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CreateAccountPlusIcon</name>
   <tag></tag>
   <elementGuidId>7d9b65d8-5273-4d1a-afe2-a6ea8efde0aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='tab-pane active'])[6]/crm-account-widget/div[1]/button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;edtTabPane&quot;]/div/div/div[9]/crm-account-widget/div[1]/button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='tab-pane active'])[3]/crm-account-widget/div[1]/button[1]</value>
   </webElementXpaths>
</WebElementEntity>
