<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Home_MyWork</name>
   <tag></tag>
   <elementGuidId>f4e63831-c1de-472f-bf2d-b28503479606</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@data-ng-class=&quot;{'navbar-item-selected': selectedItem == 'HomeMyWork'}&quot;]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//a[@data-ng-class=&quot;{'navbar-item-selected': selectedItem == 'HomeMyWork'}&quot;]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;side-menu&quot;]/li[1]/ul/li[2]/a/span</value>
   </webElementXpaths>
</WebElementEntity>
