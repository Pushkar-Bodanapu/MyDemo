<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Home_Reports</name>
   <tag></tag>
   <elementGuidId>516f2c39-dc08-457a-bdde-a7df019e3ec5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@data-ng-click=&quot;selectMenuItem('expandMyWorkMenu', 'expandHomeReportsMenu')&quot;]/span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//ul[@id='side-menu']/li/ul/li[6]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//a[@data-ng-click=&quot;selectMenuItem('expandMyWorkMenu', 'expandHomeReportsMenu')&quot;]/span[1]</value>
   </webElementXpaths>
</WebElementEntity>
