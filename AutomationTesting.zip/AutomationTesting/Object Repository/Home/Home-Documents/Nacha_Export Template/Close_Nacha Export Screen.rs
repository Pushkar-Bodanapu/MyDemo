<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Close_Nacha Export Screen</name>
   <tag></tag>
   <elementGuidId>7d0c9b92-d79c-4cfa-8afe-902be9d8bc73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;documentViewer&quot;]/rv-document-viewer/div[1]/div[3]/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;documentViewer&quot;]/rv-document-viewer/div[1]/div[3]/button</value>
   </webElementXpaths>
</WebElementEntity>
