<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Generate-Export Nacha Template Raw data file</name>
   <tag></tag>
   <elementGuidId>f7db54f1-05ab-4cbc-a919-915541ed0940</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;documentViewer&quot;]/rv-document-viewer/div[2]/div/div[3]/div/div/div/div/div/p[2]/a/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//*[@id=&quot;documentViewer&quot;]/rv-document-viewer/div[2]/div/div[3]/div/div/div/div/div/p[2]/a/i</value>
   </webElementXpaths>
</WebElementEntity>
