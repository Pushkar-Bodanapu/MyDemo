<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select Nacha Export -Raw Data from GRID</name>
   <tag></tag>
   <elementGuidId>182a171c-1c82-4711-a61b-5db191f60e8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='docList']/div[3]//span[text()='Raw Datafeed Documents'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@id='docList']/div[3]//span[text()='Raw Datafeed Documents'])[1]</value>
   </webElementXpaths>
</WebElementEntity>
