<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Home_Run Excel</name>
   <tag></tag>
   <elementGuidId>20a0d8f1-ea5b-4af8-b6d1-d570833379ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@ng-show,'isExcelOnly')] </value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body > div.modal.fade.in > div > div > div.modal-footer > div > a:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//a[contains(@ng-show,'isExcelOnly')]</value>
   </webElementXpaths>
</WebElementEntity>
